#!/bin/bash
# Builds one self-contained offline file: dist/HumzaPlasticShop-POS.html
set -e
cd "$(dirname "$0")"
mkdir -p dist
JS="src/logo.js src/base.js src/ui.js src/print.js src/urdu.js src/update.js src/server.js src/pages1.js src/pages2.js src/pages3.js src/demo.js"
{
echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Humza Plastic Store - POS</title><link rel="icon" href="data:image/png;base64,'"$(cat assets/favicon.b64)"'"><style>'
cat assets/urdufont.css src/style.css
echo '</style></head><body><div id="boot"></div><script>'
cat $JS
echo '</script></body></html>'
} > dist/HumzaPlasticShop-POS.html
cat $JS > /tmp/all_check.js; node --check /tmp/all_check.js && echo SYNTAX_OK
ls -la dist
