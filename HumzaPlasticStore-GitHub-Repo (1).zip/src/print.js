/* ================= printing & export ================= */
function printHTML(html,title){let pa=$('#printArea');if(!pa){pa=document.createElement('div');pa.id='printArea';document.body.appendChild(pa);}pa.innerHTML=html;const old=document.title;document.title=title||old;requestAnimationFrame(()=>{window.print();document.title=old;});}
function shopHead(sub){const s=db.settings;return`<div class="hd"><div><div class="shop">${esc(s.shop)}</div><div class="tagl">${esc(s.tag||'')}</div><div class="tagl">${esc(s.addr||'')}${s.phone?' | Ph: '+esc(s.phone):''}</div></div><div class="ttl"><h2>${sub}</h2></div></div>`;}
function invoiceHTML(sale){
 const c=sale.customerId?C(sale.customerId):null;let prev=0,after=0;
 if(c){const en=custEntries(c.id);const i=en.findIndex(x=>x.id===sale.id);if(i>=0){after=en[i].bal;prev=r2(after-sale.due);}else{after=custBal(c.id);prev=r2(after-sale.due);}}
 const rows=sale.items.map((i,n)=>`<tr><td class="c">${n+1}</td><td>${esc(i.name)}</td><td class="c">${num(i.qty)} ${esc(i.unit||'')}</td><td class="r">${r2(i.rate).toLocaleString()}</td><td class="r">${i.disc?r2(i.disc).toLocaleString():'-'}</td><td class="r">${r2(i.amount).toLocaleString()}</td></tr>`).join('');
 return`<div class="inv">${shopHead('SALES INVOICE')}
 <div class="meta"><div class="box"><h4>Bill To</h4><b>${esc(c?c.name:'Walk-in Customer')}</b>${c&&c.shop?'<br>'+esc(c.shop):''}${c&&c.phone?'<br>Ph: '+esc(c.phone):''}${c&&c.address?'<br>'+esc(c.address):''}</div>
 <div class="box"><h4>Invoice Details</h4>Invoice #: <b>${sale.no}</b><br>Date: <b>${fdate(sale.date)}</b> ${timeStr(sale.ts)}<br>Payment: ${esc(sale.method)}<br>Cashier: ${esc(sale.user)}</div></div>
 <table><thead><tr><th class="c" style="width:36px">#</th><th>Item Description</th><th class="c">Qty</th><th class="r">Rate</th><th class="r">Disc</th><th class="r">Amount</th></tr></thead><tbody>${rows}</tbody></table>
 <div class="tots"><div><span>Sub Total</span><span>${money(sale.subtotal)}</span></div>${sale.discount?`<div><span>Discount</span><span>- ${money(sale.discount)}</span></div>`:''}
 <div class="g"><span>Net Total</span><span>${money(sale.total)}</span></div><div><span>Paid</span><span>${money(sale.paid)}</span></div>
 ${sale.due>0?`<div class="due"><span>Balance (Udhaar)</span><span>${money(sale.due)}</span></div>`:''}
 ${c?`<div style="color:#555"><span>Previous Balance</span><span>${money(prev)}</span></div><div style="font-weight:700"><span>Total Outstanding</span><span>${money(after)}</span></div>`:''}</div>
 ${sale.note?`<div style="margin-top:10px"><b>Note:</b> ${esc(sale.note)}</div>`:''}
 <div class="sig"><span>Customer Signature</span><span>Authorized Signature</span></div>
 <div class="ft"><div>${esc(db.settings.footer||'')}</div><div>Printed: ${fdate(today())} ${timeStr(Date.now())}</div></div></div>`;}
function purchaseHTML(p){
 const s=S(p.supplierId);let after=0;{const en=suppEntries(p.supplierId);const i=en.findIndex(x=>x.id===p.id);after=i>=0?en[i].bal:suppBal(p.supplierId);}
 const rows=p.items.map((i,n)=>`<tr><td class="c">${n+1}</td><td>${esc(i.name)}</td><td class="c">${num(i.qty)} ${esc(i.unit||'')}</td><td class="r">${r2(i.rate).toLocaleString()}</td><td class="r">${i.disc?r2(i.disc).toLocaleString():'-'}</td><td class="r">${r2(i.amount).toLocaleString()}</td></tr>`).join('');
 return`<div class="inv">${shopHead('PURCHASE BILL')}
 <div class="meta"><div class="box"><h4>Supplier</h4><b>${esc(s?s.name:'')}</b>${s&&s.company?'<br>'+esc(s.company):''}${s&&s.phone?'<br>Ph: '+esc(s.phone):''}${s&&s.address?'<br>'+esc(s.address):''}</div>
 <div class="box"><h4>Bill Details</h4>Our Ref #: <b>${p.no}</b><br>Supplier Bill #: <b>${esc(p.billNo||'-')}</b><br>Date: <b>${fdate(p.date)}</b><br>Entered by: ${esc(p.user)}</div></div>
 <table><thead><tr><th class="c" style="width:36px">#</th><th>Item</th><th class="c">Qty</th><th class="r">Rate</th><th class="r">Disc</th><th class="r">Amount</th></tr></thead><tbody>${rows}</tbody></table>
 <div class="tots"><div><span>Sub Total</span><span>${money(p.subtotal)}</span></div>${p.discount?`<div><span>Discount</span><span>- ${money(p.discount)}</span></div>`:''}<div class="g"><span>Bill Total</span><span>${money(p.total)}</span></div><div><span>Paid</span><span>${money(p.paid)}</span></div>
 ${p.due>0?`<div class="due"><span>Remaining Payable</span><span>${money(p.due)}</span></div>`:''}<div style="font-weight:700"><span>Total Payable to Supplier</span><span>${money(after)}</span></div></div>
 <div class="sig"><span>Received By</span><span>Authorized Signature</span></div><div class="ft"><div>${esc(db.settings.shop)}</div><div>Printed: ${fdate(today())}</div></div></div>`;}
function voucherHTML(v,kind){ /* payment receipt / pay voucher / expense voucher */
 let title,party,extra='';
 if(kind==='exp'){title='EXPENSE VOUCHER';party=v.category;extra=v.desc||'';}
 else if(v.type==='cust'){title='PAYMENT RECEIPT';party=custName(v.partyId);extra='Received from customer';}
 else{title='PAYMENT VOUCHER';party=suppName(v.partyId);extra='Paid to supplier';}
 let bal='';if(kind!=='exp'){const b=v.type==='cust'?custBal(v.partyId):suppBal(v.partyId);bal=`<div style="margin-top:8px">${v.type==='cust'?'Remaining customer balance':'Remaining payable to supplier'}: <b>${money(b)}</b></div>`;}
 return`<div class="inv half">${shopHead(title)}<div class="meta"><div class="box"><h4>${kind==='exp'?'Expense Head':'Party'}</h4><b>${esc(party)}</b><br>${esc(extra)}</div><div class="box"><h4>Voucher</h4>No: <b>${v.no}</b><br>Date: <b>${fdate(v.date)}</b><br>Method: ${esc(v.method)}<br>By: ${esc(v.user)}</div></div>
 <div style="font-size:20px;font-weight:800;padding:10px 0">Amount: ${money(v.amount)}</div>${v.note?`<div>Note: ${esc(v.note)}</div>`:''}${bal}<div class="sig"><span>Received / Paid By</span><span>Authorized Signature</span></div></div>`;}
function returnNoteHTML(r,kind){
 const isS=kind==='sale';const rows=r.items.map((i,n)=>`<tr><td class="c">${n+1}</td><td>${esc(i.name)}</td><td class="c">${num(i.qty)}</td><td class="r">${r2(i.rate).toLocaleString()}</td><td class="r">${r2(i.amount).toLocaleString()}</td></tr>`).join('');
 return`<div class="inv">${shopHead(isS?'SALE RETURN NOTE':'PURCHASE RETURN NOTE')}<div class="meta"><div class="box"><h4>${isS?'Customer':'Supplier'}</h4><b>${esc(isS?custName(r.customerId):suppName(r.supplierId))}</b></div>
 <div class="box"><h4>Return Details</h4>Return #: <b>${r.no}</b><br>Against: <b>${isS?r.saleNo:r.purchaseNo}</b><br>Date: <b>${fdate(r.date)}</b><br>Reason: ${esc(r.reason||'-')}</div></div>
 <table><thead><tr><th class="c" style="width:36px">#</th><th>Item</th><th class="c">Qty</th><th class="r">Rate</th><th class="r">Amount</th></tr></thead><tbody>${rows}</tbody></table>
 <div class="tots"><div class="g"><span>Return Total</span><span>${money(r.total)}</span></div><div><span>Settlement</span><span>${isS?(r.mode==='cash'?'Cash refunded':'Credited to customer account'):(r.mode==='cash'?'Cash received from supplier':'Adjusted in supplier payable')}</span></div></div>
 <div class="sig"><span>Customer / Supplier</span><span>Authorized Signature</span></div></div>`;}
function ledgerHTML(title,party,entries,balLabel){
 const rows=entries.map(e=>`<tr><td>${e.date.startsWith('0000')?'':fdate(e.date)}</td><td>${esc(e.ref)}</td><td>${esc(e.desc)}</td><td style="text-align:right">${e.dr?r2(e.dr).toLocaleString():''}</td><td style="text-align:right">${e.cr?r2(e.cr).toLocaleString():''}</td><td style="text-align:right"><b>${r2(e.bal).toLocaleString()}</b></td></tr>`).join('');
 return`<div class="inv">${shopHead(title)}<div class="meta"><div class="box"><h4>Account</h4><b>${esc(party.name)}</b>${party.shop||party.company?'<br>'+esc(party.shop||party.company):''}${party.phone?'<br>Ph: '+esc(party.phone):''}</div><div class="box"><h4>${balLabel}</h4><b style="font-size:20px">${money(entries.length?entries[entries.length-1].bal:0)}</b></div></div>
 <table class="rp"><thead><tr><th>Date</th><th>Ref</th><th>Description</th><th style="text-align:right">Debit</th><th style="text-align:right">Credit</th><th style="text-align:right">Balance</th></tr></thead><tbody>${rows}</tbody></table><div class="ft"><div>Printed: ${fdate(today())}</div></div></div>`;}
function invoiceText(s){const c=s.customerId?C(s.customerId):null;let t=`*${db.settings.shop}*\nInvoice: ${s.no}\nDate: ${fdate(s.date)}\nCustomer: ${custName(s.customerId)}\n-----------------\n`;
 s.items.forEach((i,n)=>{t+=`${n+1}. ${i.name} - ${num(i.qty)} x ${r2(i.rate)} = ${r2(i.amount)}\n`;});t+=`-----------------\n`;if(s.discount)t+=`Discount: ${r2(s.discount)}\n`;t+=`*Total: ${money(s.total)}*\nPaid: ${money(s.paid)}\n`;if(s.due>0)t+=`*Balance Due: ${money(s.due)}*\n`;if(c)t+=`Total Outstanding: ${money(custBal(c.id))}\n`;t+=`\nShukriya! ${db.settings.shop}${db.settings.phone?' - '+db.settings.phone:''}`;return t;}
function purchaseText(p){let t=`*${db.settings.shop}* - Purchase Bill\nRef: ${p.no}${p.billNo?' / Bill '+p.billNo:''}\nDate: ${fdate(p.date)}\n-----------------\n`;p.items.forEach((i,n)=>{t+=`${n+1}. ${i.name} - ${num(i.qty)} x ${r2(i.rate)} = ${r2(i.amount)}\n`;});t+=`-----------------\n*Total: ${money(p.total)}*\nPaid: ${money(p.paid)}\nRemaining: ${money(p.due)}`;return t;}
const PDF_HINT='In the print window choose "Save as PDF" as destination';

/* ---------- generic report table (screen/print/excel) ---------- */
const fmtCell=(v,type)=>v===''||v==null?'':type==='money'?r2(v).toLocaleString('en-US',{maximumFractionDigits:2}):type==='num'?num(v):type==='date'?fdate(v):esc(v);
function reportTable(cols,rows,totals,cls='rp'){
 return`<table class="${cls}"><thead><tr>${cols.map(c=>`<th style="${c.type==='money'||c.type==='num'?'text-align:right':''}">${esc(c.t)}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr${r._b?' style="font-weight:800;background:#fafafa"':''}>${cols.map(c=>`<td style="${c.type==='money'||c.type==='num'?'text-align:right':''}">${c.html?r[c.k]:fmtCell(r[c.k],c.type)}</td>`).join('')}</tr>`).join('')||`<tr><td colspan="${cols.length}" style="text-align:center;padding:20px;color:#888">No data for this selection</td></tr>`}</tbody>${totals?`<tfoot><tr>${cols.map((c,i)=>`<td style="${c.type==='money'||c.type==='num'?'text-align:right':''}">${i===0?'TOTAL':totals[c.k]!=null?fmtCell(totals[c.k],c.type):''}</td>`).join('')}</tr></tfoot>`:''}</table>`;}
function printReport(title,sub,cols,rows,totals){printHTML(`<div class="rp-h"><h2>${esc(db.settings.shop)}</h2><div><b>${esc(title)}</b> ${sub?'| '+esc(sub):''}</div><div>Printed by ${esc(cur.name)} on ${fdate(today())} ${timeStr(Date.now())}</div></div>`+reportTable(cols,rows,totals),title);}
function downloadFile(name,blobOrText,type='application/octet-stream'){const b=blobOrText instanceof Blob?blobOrText:new Blob([blobOrText],{type});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},500);}
function exportExcel(title,sub,cols,rows,totals){const h=`<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="utf-8"></head><body><h2>${esc(db.settings.shop)} - ${esc(title)}</h2><p>${esc(sub||'')}</p>`+reportTable(cols,rows,totals,'x').replace(/<table/,'<table border="1"')+'</body></html>';
 downloadFile(title.replace(/[^\w]+/g,'_')+'_'+today()+'.xls','﻿'+h,'application/vnd.ms-excel;charset=utf-8');log('Exported Excel: '+title);}
