/* ================= icons ================= */
const ICONS={
dash:'<rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/>',
pos:'<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8M8 10h.01M12 10h.01M16 10h.01M8 14h.01M12 14h.01M16 14h.01M8 18h8"/>',
cart:'<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/>',
file:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>',
users:'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
user:'<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
truck:'<path d="M1 3h15v13H1zM16 8h4l3 3v5h-7z"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>',
box:'<path d="M21 16V8l-9-5-9 5v8l9 5z"/><path d="M3.3 7 12 12l8.7-5M12 22V12"/>',
layers:'<path d="m12 2-10 5 10 5 10-5z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/>',
wallet:'<path d="M20 12V8a2 2 0 0 0-2-2H4a2 2 0 0 1 0-4h14v4"/><path d="M4 6v12a2 2 0 0 0 2 2h14v-4"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/>',
book:'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V2H6.5A2.5 2.5 0 0 0 4 4.5z"/><path d="M4 19.5A2.5 2.5 0 0 0 6.5 22H20v-5"/>',
chart:'<path d="M18 20V10M12 20V4M6 20v-6"/>',
sliders:'<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
activity:'<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
download:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
ret:'<path d="M9 14 4 9l5-5"/><path d="M20 20v-7a4 4 0 0 0-4-4H4"/>',
plus:'<path d="M12 5v14M5 12h14"/>',
search:'<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
print:'<path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
x:'<path d="M18 6 6 18M6 6l12 12"/>',
edit:'<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
trash:'<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>',
alert:'<circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>',
wa:'<path d="M21 11.5a8.4 8.4 0 0 1-12.5 7.3L3 21l1.8-5.4A8.4 8.4 0 1 1 21 11.5z"/>',
cash:'<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/>',
trend:'<path d="m23 6-9.5 9.5-5-5L1 18"/><path d="M17 6h6v6"/>',
logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
check:'<path d="M20 6 9 17l-5-5"/>',
pdf:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>',
xls:'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18"/>',
tag:'<path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L2 12V2h10l8.6 8.6a2 2 0 0 1 0 2.8z"/><circle cx="7" cy="7" r="1.5"/>',
clock:'<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
eye:'<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
key:'<circle cx="7.5" cy="15.5" r="4.5"/><path d="m21 2-9.6 9.6M15.5 7.5 19 11"/>',
barcode:'<path d="M3 5v14M7 5v14M11 5v14M15 5v14M19 5v14M21 5v14"/>',
cloud:'<path d="M18 10h-1.3A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/>',
db:'<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.7-4 3-9 3s-9-1.3-9-3M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5"/>',
bag:'<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4zM3 6h18M16 10a4 4 0 0 1-8 0"/>',
pie:'<path d="M21.2 15.9A10 10 0 1 1 8 2.8"/><path d="M22 12A10 10 0 0 0 12 2v10z"/>',
};
const ic=(n,s=17)=>`<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICONS[n]||''}</svg>`;

/* ================= modal / toast ================= */
const modals=[];
function modal(html,{wide,mid,focus=true}={}){
 const w=document.createElement('div');w.className='mw';w.innerHTML=`<div class="md ${wide?'wide':mid?'mid':''}">${html}</div>`;document.body.appendChild(w);modals.push(w);
 w.close=()=>{const i=modals.indexOf(w);if(i>=0)modals.splice(i,1);w.remove();if(w.onclose)w.onclose();};
 w.addEventListener('mousedown',e=>{if(e.target===w&&!w.sticky)w.close();});
 w.addEventListener('click',e=>{if(e.target.closest('[data-close]'))w.close();});
 if(focus){const f=$('input:not([type=hidden]):not([readonly]),select,textarea',w);if(f)setTimeout(()=>{f.focus();f.select&&f.type!=='date'&&f.select();},30);}
 return w;}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modals.length){modals[modals.length-1].close();e.stopPropagation();}},true);
function toast(msg,type='ok'){let h=$('#toasts');if(!h){h=document.createElement('div');h.id='toasts';document.body.appendChild(h);}const t=document.createElement('div');t.className='toast '+type;t.textContent=msg;h.appendChild(t);setTimeout(()=>t.remove(),type==='err'?4500:2600);}
function confirmBox(msg,okText='Yes, continue',danger=false){return new Promise(res=>{const m=modal(`<div class="mb"><div style="font-size:15px;font-weight:600;line-height:1.5">${msg}</div></div><div class="mf"><button class="btn" data-no>Cancel</button><button class="btn ${danger?'red':'pri'}" data-yes>${okText}</button></div>`,{focus:false});let done=false;const fin=v=>{if(done)return;done=true;m.close();res(v);};$('[data-yes]',m).onclick=()=>fin(true);$('[data-no]',m).onclick=()=>fin(false);m.onclose=()=>fin(false);$('[data-yes]',m).focus();});}

/* ================= forms ================= */
function fieldHTML(f,v){
 const val=v??f.def??'';let inp='';
 const attrs=`${f.cls?`class="${f.cls}"`:""} name="${f.k}" ${f.ph?`placeholder="${esc(f.ph)}"`:''} ${f.readonly?'readonly':''} ${f.list?`list="dl-${f.k}"`:''}`;
 if(f.type==='select')inp=`<select ${attrs}>${f.opts.map(o=>{const [a,b]=Array.isArray(o)?o:[o,o];return`<option value="${esc(a)}" ${String(a)===String(val)?'selected':''}>${esc(b)}</option>`;}).join('')}</select>`;
 else if(f.type==='textarea')inp=`<textarea ${attrs} rows="2">${esc(val)}</textarea>`;
 else if(f.type==='check')return`<div class="f ${f.full?'full':''}"><label style="display:flex;align-items:center;gap:8px;margin-top:6px"><input type="checkbox" name="${f.k}" ${val?'checked':''}> ${f.label}</label></div>`;
 else inp=`<input type="${f.type||'text'}" ${f.type==='number'?'step="any"':''} ${attrs} value="${esc(val)}" autocomplete="off">`;
 const dl=f.list?`<datalist id="dl-${f.k}">${f.list.map(x=>`<option value="${esc(x)}">`).join('')}</datalist>`:'';
 return`<div class="f ${f.full?'full':''} ${f.req?'req':''}"><label>${f.label}</label>${inp}${dl}${f.hint?`<div class="hint">${f.hint}</div>`:''}</div>`;}
function formModal({title,fields,values={},onSave,save='Save',wide,mid,extra='',after}){
 const m=modal(`<div class="mh"><h3>${title}</h3><button class="x" data-close>${ic('x',20)}</button></div><form class="mb fg" autocomplete="off">${fields.map(f=>fieldHTML(f,values[f.k])).join('')}${extra}<button type="submit" hidden></button></form><div class="mf"><button class="btn" data-close type="button">Cancel</button><button class="btn pri" data-save type="button">${save}</button></div>`,{wide,mid});
 const form=$('form',m);
 const submit=()=>{const v={};for(const f of fields){const el=form.elements[f.k];let x=f.type==='check'?el.checked:el.value;if(f.type==='number')x=x===''?'':+x;else if(typeof x==='string')x=x.trim();if(f.req&&(x===''||x==null)){toast(f.label+' is required','err');el.focus();return;}v[f.k]=x;}
  const r=onSave(v,m,form);if(r!==false)m.close();};
 form.onsubmit=e=>{e.preventDefault();submit();};$('[data-save]',m).onclick=submit;formNav(form,submit);if(after)after(m,form);return m;}

/* ================= picker (keyboard dropdown) ================= */
function attachPicker(inp,{items,render,onPick,openOnFocus=false}){
 const dd=document.createElement('div');dd.className='dd';inp.parentNode.style.position='relative';inp.parentNode.appendChild(dd);
 let list=[],idx=0;
 const draw=()=>{if(!list.length||document.activeElement!==inp){dd.style.display='none';return;}dd.style.display='block';dd.innerHTML=list.map((it,i)=>`<div class="dd-i ${i===idx?'on':''}" data-i="${i}">${render(it)}</div>`).join('');const on=dd.querySelector('.on');if(on)on.scrollIntoView({block:'nearest'});};
 const refresh=()=>{list=items(inp.value.trim());idx=0;draw();};
 inp.addEventListener('input',refresh);
 inp.addEventListener('focus',()=>{if(openOnFocus)refresh();});
 inp.addEventListener('blur',()=>setTimeout(()=>{if(document.activeElement!==inp)dd.style.display='none';},160));
 inp.addEventListener('keydown',e=>{if(dd.style.display!=='block')return;
  if(e.key==='ArrowDown'){idx=Math.min(idx+1,list.length-1);draw();e.preventDefault();e.stopPropagation();}
  else if(e.key==='ArrowUp'){idx=Math.max(idx-1,0);draw();e.preventDefault();e.stopPropagation();}
  else if(e.key==='Enter'||e.key==='Tab'&&list.length&&inp.value.trim()&&inp.dataset.tabpick){e.preventDefault();e.stopPropagation();pick(list[idx]);}
  else if(e.key==='Escape'){dd.style.display='none';e.stopPropagation();}});
 dd.addEventListener('mousedown',e=>{const el=e.target.closest('.dd-i');if(el){e.preventDefault();pick(list[+el.dataset.i]);}});
 function pick(it){if(it===undefined)return;dd.style.display='none';onPick(it,inp);}
 return{refresh,close:()=>{dd.style.display='none';}};}

/* product search (shared) */
function searchProducts(q,limit=14){q=q.toLowerCase();if(!q)return[];const toks=q.split(/\s+/);
 const out=[];for(const p of db.products){if(p.active===false)continue;const hay=(p.name+' '+p.code+' '+(p.barcode||'')+' '+(p.brand||'')+' '+(p.category||'')).toLowerCase();if(!toks.every(t=>hay.includes(t)))continue;
  let sc=3;if(p.barcode&&p.barcode.toLowerCase()===q||String(p.code).toLowerCase()===q)sc=0;else if(p.name.toLowerCase().startsWith(q))sc=1;else if(p.name.toLowerCase().includes(q))sc=2;out.push([sc,p]);}
 return out.sort((a,b)=>a[0]-b[0]||a[1].name.localeCompare(b[1].name)).slice(0,limit).map(x=>x[1]);}

/* line entry: item -> qty -> rate -> disc, Enter to add. Fully keyboard driven */
function lineEntry(host,cfg){
 host.innerHTML=cfg.tpl||`<div class="le"><div class="f grow"><label>${ic('barcode',13)} Item (name / code / barcode) - Enter to select</label><input id="le-s" autocomplete="off" placeholder="Type item name, code or scan barcode..."></div><div class="f w90"><label>Qty</label><input id="le-q" type="number" step="any" min="0" disabled></div><div class="f w110"><label>${cfg.rateLabel||'Rate'}</label><input id="le-r" type="number" step="any" min="0" ${cfg.lockRate?'':'disabled'}></div><div class="f w90"><label>Disc (Rs)</label><input id="le-d" type="number" step="any" min="0" disabled></div><button class="btn pri" id="le-a" type="button" style="height:42px">${ic('plus')} Add</button></div><div class="le-info" id="le-i">Search an item to begin. After picking an item press <b>Enter</b> for quantity, <b>Tab</b> to change rate/discount, <b>Enter</b> to add.</div>`;
 const s=$('#le-s',host),q=$('#le-q',host),r=$('#le-r',host),d=$('#le-d',host),info=$('#le-i',host);let curP=null;
 const lock=on=>{q.disabled=r.disabled=d.disabled=!on;};
 const reset=()=>{curP=null;s.value='';q.value=r.value=d.value='';lock(false);info.innerHTML='Search an item to begin. After picking an item press <b>Enter</b> for quantity, <b>Tab</b> to change rate/discount, <b>Enter</b> to add.';};
 const setItem=(p,vals={})=>{curP=p;s.value=p.name;lock(true);q.value=vals.qty??1;r.value=vals.rate??cfg.rate(p);d.value=vals.disc??'';
  info.innerHTML=cfg.info?cfg.info(p):'';q.focus();q.select();};
 const add=()=>{if(!curP){s.focus();return;}const qty=+q.value,rate=+r.value;if(!(qty>0)){toast('Enter quantity','err');q.focus();return;}if(!(rate>=0)||r.value===''){toast('Enter rate','err');r.focus();return;}
  const ok=cfg.onAdd({pid:curP.id,name:curP.name,unit:curP.unit,qty,rate,disc:+d.value||0,product:curP});if(ok===false)return;reset();s.focus();};
 attachPicker(s,{items:q0=>{const l=searchProducts(q0);return l;},render:cfg.renderItem,onPick:(p)=>{
   if(cfg.scan&&(p.barcode&&p.barcode===s.value.trim())){curP=p;q.value=1;r.value=cfg.rate(p);d.value='';add();return;}
   setItem(p);}});
 s.addEventListener('keydown',e=>{if(e.key!=='Enter'||e.defaultPrevented)return;e.preventDefault();if(!s.value.trim()||curP){cfg.onEmptyEnter&&cfg.onEmptyEnter();}else toast('No matching item','warn');});
 [q,r,d].forEach(el=>el.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();add();}else if(e.key==='Escape'){reset();s.focus();e.stopPropagation();}}));
 $('#le-a',host).onclick=add;
 return{focus:()=>s.focus(),edit:(p,vals)=>setItem(p,vals),reset,search:s};}

/* ================= table helpers ================= */
function tbl(cols,rows,opt={}){return`<div class="tw"><table class="t ${opt.cls||''}"><thead><tr>${cols.map(c=>`<th class="${c.cls||''}">${c.t}</th>`).join('')}</tr></thead><tbody>${rows.length?rows.map(r=>`<tr ${opt.attr?opt.attr(r):''}>${cols.map(c=>`<td class="${c.cls||''}">${c.k(r)}</td>`).join('')}</tr>`).join(''):`<tr><td colspan="${cols.length}" class="empty">${opt.empty||'No records found'}</td></tr>`}</tbody>${opt.foot?`<tfoot>${opt.foot}</tfoot>`:''}</table></div>`;}
const head=(t,sub,actions='')=>`<div class="ph"><div><h1>${t}</h1>${sub?`<p>${sub}</p>`:''}</div><div class="ac">${actions}</div></div>`;
const balCls=b=>b>0?'pos-c':b<0?'neg-c':'';
const statusBadge=(due,total)=>due<=0?'<span class="bd green">Paid</span>':due>=total?'<span class="bd red">Udhaar</span>':'<span class="bd orange">Partial</span>';
function rangeOf(key){const t=today();const d=new Date();
 if(key==='today')return[t,t];if(key==='yesterday'){const y=addDays(t,-1);return[y,y];}
 if(key==='week')return[addDays(t,-6),t];if(key==='month')return[ymd(new Date(d.getFullYear(),d.getMonth(),1)),t];
 if(key==='lastmonth')return[ymd(new Date(d.getFullYear(),d.getMonth()-1,1)),ymd(new Date(d.getFullYear(),d.getMonth(),0))];
 if(key==='year')return[d.getFullYear()+'-01-01',t];if(key==='all')return['0000-00-00','9999-12-31'];return[t,t];}
const RANGE_OPTS=[['today','Today'],['yesterday','Yesterday'],['week','Last 7 days'],['month','This month'],['lastmonth','Last month'],['year','This year'],['all','All time'],['custom','Custom']];

/* ================= router ================= */
const V={};let cleanups=[];
const onLeave=f=>cleanups.push(f);
const PAGE_MOD={customer:'customers',supplier:'suppliers',purchaseNew:'purchases'};
function nav(p,a=''){const h='#/'+p+(a?'/'+a:'');if(location.hash===h)route();else location.hash=h;}
function route(){if(!db)return;if(!cur)return showLogin();const h=location.hash.replace(/^#\//,'')||(can('dashboard')?'dashboard':'pos');const [p,...rest]=h.split('/');renderPage(p,rest.join('/'));}
function renderPage(p,arg){cleanups.forEach(f=>{try{f();}catch(e){}});cleanups=[];
 if(!V[p])p='dashboard';const mod=PAGE_MOD[p]||p;if(!can(mod)){toast('You do not have permission for this page','err');p=can('pos')?'pos':Object.keys(V).find(k=>can(PAGE_MOD[k]||k))||'pos';}
 const old=$('#view');if(!old)return;const nv=document.createElement('div');nv.id='view';nv.className='page';old.replaceWith(nv);
 const tid=(typeof TILE_OF!=='undefined'&&TILE_OF[p])||p;$$('.tile').forEach(a=>a.classList.toggle('on',a.dataset.p===tid));
 window.scrollTo(0,0);try{V[p](nv,arg);const gk=GROUP_OF[p];if(gk)nv.insertAdjacentHTML('afterbegin',`<div class="subnav">${SUBNAV[gk].filter(x=>can(PAGE_MOD[x[0]]||x[0])).map(x=>`<a href="#/${x[0]}" class="sn ${x[0]===p?'on':''}">${x[1]}</a>`).join('')}</div>`);}catch(e){console.error(e);nv.innerHTML=`<div class="card cb">Error: ${esc(e.message)}</div>`;}
 const lw=$('#lowBadge');if(lw){const n=lowItems().length;lw.textContent=n||'';lw.style.display=n?'inline-block':'none';}}
window.addEventListener('hashchange',route);

/* ===== keyboard navigation inside forms: arrows + Enter ===== */
function formNav(form,onEnd){
 const fl=()=>[...form.querySelectorAll('input:not([type=hidden]):not([readonly]):not([disabled]),select,textarea')].filter(e=>e.offsetParent&&e.type!=='checkbox'||(e.type==='checkbox'&&e.offsetParent));
 const go=(el,d)=>{const l=fl(),i=l.indexOf(el),n=l[i+d];if(n){n.focus();n.select&&['text','number','search','tel'].includes(n.type)&&n.select();return true;}return false;};
 const geo=(el,dir)=>{const l=fl(),r=el.getBoundingClientRect();let best=null,bd=1e9;for(const o of l){if(o===el)continue;const q=o.getBoundingClientRect();const dy=(q.top+q.height/2)-(r.top+r.height/2);if(dir>0?dy<=4:dy>=-4)continue;const dx=Math.abs(q.left-r.left);const sc=Math.abs(dy)*1+dx*3;if(sc<bd){bd=sc;best=o;}}if(best){best.focus();best.select&&['text','number'].includes(best.type)&&best.select();return true;}return false;};
 form.addEventListener('keydown',e=>{const el=e.target;if(!el.matches||!el.matches('input,select,textarea'))return;if(e.altKey||e.ctrlKey||e.metaKey)return;
  if(el.parentNode.querySelector('.dd')&&el.parentNode.querySelector('.dd').style.display==='block')return;
  const k=e.key;
  if(k==='Enter'){if(el.tagName==='TEXTAREA'&&e.shiftKey)return;e.preventDefault();if(!go(el,1)&&onEnd)onEnd();return;}
  if(k==='ArrowDown'){e.preventDefault();if(!geo(el,1))go(el,1);return;}
  if(k==='ArrowUp'){e.preventDefault();if(!geo(el,-1))go(el,-1);return;}
  const txt=['text','number','search','tel','date'].includes(el.type)||el.tagName==='TEXTAREA';
  const atS=!txt||(el.selectionStart===0&&el.selectionEnd===0)||(el.selectionStart===0&&el.selectionEnd===el.value.length);
  const atE=!txt||(el.selectionStart===el.value.length)||(el.selectionStart===0&&el.selectionEnd===el.value.length);
  if(k==='ArrowRight'&&atE){e.preventDefault();go(el,1);}
  if(k==='ArrowLeft'&&atS){e.preventDefault();go(el,-1);}
 });}

/* ===== global arrow-key navigation (all pages, POS, dialogs) ===== */
document.addEventListener('keydown',e=>{
 if(e.defaultPrevented||e.altKey||e.ctrlKey||e.metaKey||e.shiftKey)return;
 const k=e.key;if(!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(k))return;
 const el=e.target;if(!el||!el.matches||!el.matches('input,select,textarea,button'))return;
 if(el.type==='date'||el.type==='time'||el.type==='month'||el.type==='range'||el.type==='file')return;
 const box=el.closest('.md')||el.closest('#view');if(!box)return;
 if(el.tagName==='TEXTAREA'&&(k==='ArrowUp'||k==='ArrowDown')&&el.value.includes('\n'))return;
 const dd=el.parentNode&&el.parentNode.querySelector&&el.parentNode.querySelector('.dd');if(dd&&dd.style.display==='block'&&(k==='ArrowUp'||k==='ArrowDown'))return;
 const list=[...box.querySelectorAll('input:not([type=hidden]):not([type=file]),select,textarea,button')].filter(x=>!x.disabled&&!x.readOnly&&x.offsetParent&&x.tabIndex>=0&&!x.closest('[hidden]'));
 const i=list.indexOf(el);if(i<0)return;
 const focus=n=>{n.focus();if(n.select&&['text','number','search','tel'].includes(n.type))n.select();e.preventDefault();};
 const mid=r=>[r.left+r.width/2,r.top+r.height/2];
 if(k==='ArrowLeft'||k==='ArrowRight'){
  if(['text','number','search','tel','email','password'].includes(el.type)||el.tagName==='TEXTAREA'){let s=el.selectionStart,en=el.selectionEnd;const L=el.value.length;if(s==null){s=en=el.type==='number'?(k==='ArrowRight'?L:0):0;}const all=s===0&&en===L;
   if(k==='ArrowRight'&&!(all||(s===L&&en===L)))return;if(k==='ArrowLeft'&&!(all||(s===0&&en===0)))return;}
  const n=list[i+(k==='ArrowRight'?1:-1)];if(n)focus(n);return;}
 const dir=k==='ArrowDown'?1:-1,[cx,cy]=mid(el.getBoundingClientRect());let best=null,bs=1e9;
 for(const o of list){if(o===el)continue;const [ox,oy]=mid(o.getBoundingClientRect());const dy=(oy-cy)*dir;if(dy<=4)continue;const sc=dy+Math.abs(ox-cx)*2.5;if(sc<bs){bs=sc;best=o;}}
 if(best)focus(best);
});
