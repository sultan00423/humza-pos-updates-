/* ================= Urdu support: names, units, Urdu A4 invoice ================= */
const UR_UNIT={Pcs:'عدد',Dozen:'درجن',Set:'سیٹ',Kg:'کلو',Meter:'میٹر',Feet:'فٹ',Box:'ڈبہ',Packet:'پیکٹ',Bag:'بوری',Pair:'جوڑی'};
const UR_DAYS=['اتوار','پیر','منگل','بدھ','جمعرات','جمعہ','ہفتہ'];
const UR_DICT={'plastic':'پلاسٹک','bucket':'بالٹی','mug':'مگ','bath':'باتھ','jug':'جگ','water':'واٹر','dustbin':'ڈسٹ بن','pedal':'پیڈل','tub':'ٹب','basket':'ٹوکری','laundry':'لانڈری','fruit':'فروٹ','chair':'کرسی','armless':'بغیر بازو','with arms':'بازو والی','stool':'اسٹول','table':'میز','small':'چھوٹا','big':'بڑا','large':'بڑا','medium':'درمیانہ','box':'ڈبہ','storage':'اسٹوریج','bottle':'بوتل','lunch':'لنچ','set':'سیٹ','food':'فوڈ','container':'کنٹینر','drum':'ڈرم','tank':'ٹینکی','rope':'رسی','hanger':'ہینگر','dish':'ڈش','rack':'ریک','spoon':'چمچ','pack':'پیک','pot':'گملا','garden':'گارڈن','pvc':'پی وی سی','pipe':'پائپ','sheet':'شیٹ','glass':'گلاس','plate':'پلیٹ','bowl':'باؤل','tray':'ٹرے','cup':'کپ','basin':'لگن','tiffin':'ٹفن','layer':'لیئر','dozen':'درجن','blue':'نیلا','red':'سرخ','green':'سبز','white':'سفید','black':'کالا','yellow':'پیلا','pink':'گلابی','kitchen':'کچن','lid':'ڈھکن','broom':'جھاڑو','mop':'پوچا','stand':'اسٹینڈ','cooler':'کولر','flask':'تھرماس','bag':'تھیلا','toy':'کھلونا','inch':'انچ','meter':'میٹر','kg':'کلو','piece':'عدد','pcs':'عدد','pc':'عدد','house':'ہاؤس','bathroom':'باتھ روم','shelf':'شیلف','organizer':'آرگنائزر','bin':'بن','with':'والا','and':'اور','top':'ٹاپ','cover':'کور','net':'جالی','wash':'واش','ice':'آئس','tong':'چمٹا','soap':'صابن','case':'کیس','dish rack':'ڈش ریک','food container':'فوڈ کنٹینر','lunch box':'لنچ باکس','water bottle':'واٹر بوتل','water tank':'واٹر ٹینکی','water jug':'واٹر جگ','storage box':'اسٹوریج باکس','laundry basket':'لانڈری ٹوکری','fruit basket':'فروٹ ٹوکری','garden pot':'گارڈن گملا','plastic rope':'پلاسٹک رسی','plastic hanger':'پلاسٹک ہینگر','plastic sheet':'پلاسٹک شیٹ','bath mug':'باتھ مگ'};
const UR_NUMUNIT={l:'لیٹر',ltr:'لیٹر',ml:'ملی لیٹر',kg:'کلو',g:'گرام',pc:'عدد',pcs:'عدد',inch:'انچ',in:'انچ',ft:'فٹ',mm:'ملی میٹر',cm:'سینٹی میٹر',m:'میٹر'};
function autoUrdu(name){
 const w=String(name||'').trim().split(/\s+/).filter(Boolean);const out=[];let i=0;
 while(i<w.length){let done=false;
  for(let n=3;n>=1&&!done;n--){if(i+n>w.length)continue;const k=w.slice(i,i+n).join(' ').toLowerCase();if(UR_DICT[k]){out.push(UR_DICT[k]);i+=n;done=true;}}
  if(done)continue;const m=w[i].match(/^(\d+(?:\.\d+)?)([a-zA-Z]+)$/);
  if(m&&UR_NUMUNIT[m[2].toLowerCase()]){out.push(m[1]+' '+UR_NUMUNIT[m[2].toLowerCase()]);}else out.push(w[i]);i++;}
 return out.join(' ');}
const UR_FONTS={auto:"'Jameel Noori Nastaleeq','Noto Nastaliq Urdu','Urdu Typesetting','Tahoma','Segoe UI','HP Urdu',Arial",clear:"'Segoe UI','Tahoma','HP Urdu',Arial",typesetting:"'Urdu Typesetting','Tahoma','HP Urdu'",noori:"'Jameel Noori Nastaleeq','Tahoma','HP Urdu'",embedded:"'HP Urdu'"};
function applyUrduFont(){const s=db.settings,r=document.documentElement.style;r.setProperty('--urfont',UR_FONTS[s.urduFont]||UR_FONTS.auto);r.setProperty('--ursize',((+s.urduSize||100)/100)+'');r.setProperty('--urw',s.urduBold?'700':'400');}
const logoSrc=()=>db.settings.logo||DEFAULT_LOGO;
const urName=i=>i.nameUr||(P(i.pid)&&P(i.pid).nameUr)||autoUrdu(i.name);
const invLang=()=>db.settings.invoiceLang||'ur';
const invoicePrintHTML=(s,lang)=>(lang||invLang())==='ur'?invoiceUrduHTML(s):invoiceHTML(s);
const urDrCr=b=>b>=0?'Dr.':'Cr.';
function invoiceUrduHTML(sale){
 const st=db.settings,c=sale.customerId?C(sale.customerId):null;let prev=0,after=0;
 if(c){const en=custEntries(c.id);const i=en.findIndex(x=>x.id===sale.id);after=i>=0?en[i].bal:custBal(c.id);prev=r2(after-sale.due);}
 const hasDisc=sale.items.some(i=>i.disc>0);const dmy=ds=>{const d=new Date(ds+'T00:00:00');return pad(d.getDate())+'/'+pad(d.getMonth()+1)+'/'+d.getFullYear();};
 const dd=new Date(sale.date+'T00:00:00');
 const rows=sale.items.map((i,n)=>{const p=P(i.pid);return`<tr><td class="c">${n+1}</td><td class="c">${esc(p?p.code:'')}</td><td class="nm">${esc(urName(i))}</td><td class="c">${UR_UNIT[i.unit]||esc(i.unit||'')}</td><td class="c">${num(i.qty)}</td><td class="l">${r2(i.rate).toFixed(2)}</td>${hasDisc?`<td class="l">${i.disc?r2(i.disc).toFixed(2):''}</td>`:''}<td class="l">${r2(i.amount).toFixed(2)}</td></tr>`;}).join('');
 const nc=hasDisc?8:7,q=num(sum(sale.items,'qty'));
 const foot=(st.footerUr||'').split('\n').filter(x=>x.trim()).map(x=>`<div>${esc(x)}</div>`).join('');
 const kv=(a,b,cls='')=>`<tr class="${cls}"><td class="k">${a}</td><td class="v">${b}</td></tr>`;
 const bal=b=>r2(Math.abs(b)).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})+' <small>'+(b>=0?'Dr.':'Cr.')+'</small>';
 const od=+st.overdueDays||30,due=sale.dueDate||addDays(sale.date,od),dd2=new Date(due+'T00:00:00');
 const notice=c&&after>0?`<div class="unot"><div class="uh">آمد اطلاع</div><div class="ub">مورخہ <b dir="ltr">${dmy(due)}</b> بروز <b>${UR_DAYS[dd2.getDay()]}</b><div class="us">اپنے معاہدے کے مطابق رقم تیار رکھیں، شکریہ!</div></div></div>`:'';
 return`<div class="inv ur"><div class="uhead"><div class="utitle">فروخت بل</div><div class="ushopn"><img class="ulogo" src="${logoSrc()}" alt=""><div><div class="un">${esc(st.shopUr||st.shop)}</div>${st.addrUr?`<div class="ua">${esc(st.addrUr)}</div>`:''}${st.phone?`<div class="ua" dir="ltr">${esc(st.phone)}</div>`:''}</div></div></div>
 <div class="ubox ucust">بل بنام: <b>${esc(c?c.name:'نقد گاہک')}</b>${c&&c.shop?' - '+esc(c.shop):''}${c&&(c.address||c.area)?`<span class="uadr">${esc([c.address,c.area].filter(Boolean).join('، '))}</span>`:''}</div>
 <div class="umeta"><span>صفحہ نمبر: <b dir="ltr">1/1</b></span><span>بل نمبر: <b dir="ltr">${sale.no}</b></span><span>تاریخ: <b dir="ltr">${dmy(sale.date)} ${new Date(sale.ts).toLocaleTimeString('en-US')}</b></span><span>${UR_DAYS[dd.getDay()]}</span></div>
 <table class="ut"><thead><tr><th style="width:34px">#</th><th style="width:62px">کوڈ</th><th>تفصیل اشیاء</th><th style="width:56px">یونٹ</th><th style="width:62px">تعداد</th><th style="width:84px">ریٹ</th>${hasDisc?'<th style="width:70px">رعایت</th>':''}<th style="width:96px">رقم</th></tr></thead><tbody>${rows}</tbody>
 <tfoot><tr><td colspan="${nc-4}" class="lb">صفحہ ٹوٹل :</td><td class="c">${q}</td><td colspan="${hasDisc?2:1}"></td><td class="l">${r2(sale.subtotal).toFixed(2)}</td></tr><tr><td colspan="${nc-4}" class="lb">کل میزان :</td><td class="c">${q}</td><td colspan="${hasDisc?2:1}"></td><td class="l">${r2(sale.subtotal).toFixed(2)}</td></tr></tfoot></table>
 <div class="ubot"><div class="uleft">${notice}<div class="uprep"><div class="un2">${esc(sale.user)}</div><b dir="ltr">Prepared By</b></div></div>
 <div class="uacc"><table class="ut2">${kv('بل رقم',r2(sale.subtotal).toLocaleString('en-US',{minimumFractionDigits:2}))}${sale.discount?kv('ڈسکاؤنٹ',r2(sale.discount).toLocaleString('en-US',{minimumFractionDigits:2})):''}${kv('نیٹ بل',r2(sale.total).toLocaleString('en-US',{minimumFractionDigits:2}),'b')}${c?kv('سابقہ بیلنس',bal(prev))+kv('میزان',bal(prev+sale.total),'i')+kv('وصول',r2(sale.paid).toLocaleString('en-US',{minimumFractionDigits:2}))+kv('موجودہ بیلنس',bal(after),'b'):kv('وصول',r2(sale.paid).toLocaleString('en-US',{minimumFractionDigits:2}))+(sale.due>0?kv('باقی',r2(sale.due).toLocaleString('en-US',{minimumFractionDigits:2}),'b'):'')}</table></div></div>
 ${sale.note?`<div class="ua" style="margin-top:6px">نوٹ: ${esc(sale.note)}</div>`:''}
 <div class="ufoot">${foot}${st.phone?`<div>شکایت یا آرڈر کے لیے رابطہ کریں: <span dir="ltr">${esc(st.phone)}</span></div>`:''}</div></div>`;}
function invoiceTextUr(s){const c=s.customerId?C(s.customerId):null;let t=`*${db.settings.shopUr||db.settings.shop}*\nبل نمبر: ${s.no}\nتاریخ: ${fdate(s.date)}\nبنام: ${c?c.name:'نقد گاہک'}\n-----------------\n`;
 s.items.forEach((i,n)=>{t+=`${n+1}. ${urName(i)} - ${num(i.qty)} x ${r2(i.rate)} = ${r2(i.amount)}\n`;});t+=`-----------------\n`;if(s.discount)t+=`ڈسکاؤنٹ: ${r2(s.discount)}\n`;t+=`*نیٹ بل: ${money(s.total)}*\nوصول: ${money(s.paid)}\n`;if(s.due>0)t+=`*باقی: ${money(s.due)}*\n`;if(c)t+=`کل بقایا: ${money(custBal(c.id))}\n`;t+=`\nشکریہ!${db.settings.phone?' '+db.settings.phone:''}`;return t;}
