/* ===== PC data safety via local launcher service (Windows installed version) ===== */
const SRV=location.protocol==='http:'&&location.hostname==='127.0.0.1';
const sv=async(path,o={})=>{const r=await fetch(path,{...o,headers:{'X-HP':'1',...(o.headers||{})}});if(!r.ok)throw new Error('HTTP '+r.status);return r.json();};
let mirrorT=null;
function mirrorSoon(){if(!SRV)return;clearTimeout(mirrorT);mirrorT=setTimeout(()=>{if(db)sv('/api/mirror',{method:'POST',body:JSON.stringify(db)}).catch(()=>{});},12000);}
if(SRV){setInterval(()=>{sv('/api/ping').catch(()=>{});},20000);sv('/api/ping').catch(()=>{});}
async function srvBackup(kind){try{return await sv('/api/backup?kind='+(kind||'daily'),{method:'POST',body:JSON.stringify(db)});}catch(e){return{ok:false,error:e.message};}}
async function srvRestoreIfEmpty(){if(!SRV)return null;try{const r=await fetch('/api/latest',{headers:{'X-HP':'1'}});if(!r.ok)return null;const d=await r.json();return d&&Array.isArray(d.products)&&Array.isArray(d.users)?d:null;}catch(e){return null;}}
