/* ================= update check via GitHub Releases (no server needed) ================= */
const verNum=v=>String(v||'').replace(/^[^\d]*/,'').split('.').map(x=>parseInt(x)||0);
const verGt=(a,b)=>{const x=verNum(a),y=verNum(b);for(let i=0;i<3;i++){if((x[i]||0)!==(y[i]||0))return(x[i]||0)>(y[i]||0);}return false;};
async function checkUpdate(manual){
 const repo=(db.settings.updateRepo||UPDATE_REPO_DEFAULT||'').trim();
 if(!repo){if(manual)toast('Settings mein GitHub repo (owner/name) likhen','warn');return;}
 try{const r=await fetch(`https://api.github.com/repos/${repo}/releases/latest`,{headers:{Accept:'application/vnd.github+json'}});
  if(!r.ok)throw new Error(r.status===404?'Release nahi mili (repo ya release check karen)':'HTTP '+r.status);
  const j=await r.json();db.settings.lastUpdateCheck=today();save();
  if(!verGt(j.tag_name,APP_VERSION)){if(manual)toast('Aap ka software up-to-date hai (v'+APP_VERSION+')');return;}
  if(!manual&&db.settings.skipVersion===j.tag_name)return;
  const asset=(j.assets||[]).find(a=>/setup.*\.exe$/i.test(a.name))||(j.assets||[])[0];const url=asset?asset.browser_download_url:j.html_url;
  const m=modal(`<div class="mh"><h3>Naya update available: ${esc(j.tag_name)}</h3><button class="x" data-close>${ic('x',20)}</button></div><div class="mb"><p style="margin-top:0">Aap ka version: <b>v${APP_VERSION}</b> &nbsp;&rarr;&nbsp; Naya: <b>${esc(j.tag_name)}</b></p><div style="white-space:pre-wrap;max-height:220px;overflow:auto;background:#f7f8fa;border:1px solid var(--bd);border-radius:8px;padding:10px;font-size:12.5px">${esc(j.body||'Bug fixes aur improvements.')}</div><p class="mut sm" style="margin-bottom:0">Download hone ke baad file chalayen - purana data safe rahega. Update se pehle Backup le len.</p></div><div class="mf"><button class="btn" id="u-skip">Is version ko skip karein</button><button class="btn" data-close>Baad mein</button><button class="btn pri" id="u-dl">Download Update</button></div>`,{focus:false});
  $('#u-dl',m).onclick=()=>{window.open(url,'_blank');m.close();};$('#u-skip',m).onclick=()=>{db.settings.skipVersion=j.tag_name;save();m.close();};
 }catch(e){if(manual)toast('Update check nahi ho saka: '+e.message,'err');}}
function autoUpdateCheck(){if(!navigator.onLine||db.settings.lastUpdateCheck===today())return;setTimeout(()=>checkUpdate(false),4000);}
