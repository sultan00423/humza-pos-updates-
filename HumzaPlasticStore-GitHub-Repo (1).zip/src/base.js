'use strict';
const SS={};
window.addEventListener('error',e=>{const d=document.getElementById('boot');if(d)d.innerHTML='<b style="color:#c00">Error: '+String(e.message).replace(/</g,'&lt;')+'</b><br>Please open this file in Google Chrome or Microsoft Edge on your computer.';});
/* ================= helpers ================= */
const $=(s,e=document)=>e.querySelector(s), $$=(s,e=document)=>[...e.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const r2=x=>Math.round((+x||0)*100)/100, r3=x=>Math.round((+x||0)*1000)/1000;
const sum=(a,f)=>a.reduce((s,x)=>s+(+(typeof f==='function'?f(x):x[f])||0),0);
const money=x=>{x=r2(x);return (x<0?'-':'')+'Rs '+Math.abs(x).toLocaleString('en-US',{minimumFractionDigits:0,maximumFractionDigits:2});};
const num=x=>r3(x).toLocaleString('en-US',{maximumFractionDigits:3});
const pad=n=>String(n).padStart(2,'0');
const ymd=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const today=()=>ymd(new Date());
const addDays=(s,n)=>{const d=new Date(s+'T00:00:00');d.setDate(d.getDate()+n);return ymd(d);};
const MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const fdate=s=>{if(!s)return'';const [y,m,d]=s.split('-');return d+'-'+MON[+m-1]+'-'+y;};
const daysBetween=(a,b)=>Math.round((new Date(b+'T00:00:00')-new Date(a+'T00:00:00'))/864e5);
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const timeStr=ts=>{const d=new Date(ts);return pad(d.getHours())+':'+pad(d.getMinutes());};
const METHODS=['Cash','Bank Transfer','Easypaisa','JazzCash','Cheque'];
const UNITS=['Pcs','Dozen','Set','Kg','Meter','Feet','Box','Packet','Bag','Pair'];
const EXP_CATS=['Rent','Electricity','Salary','Transport','Tea / Food','Repair','Packing','Mobile / Internet','Misc'];
const MODULES=[['dashboard','Dashboard'],['pos','POS Billing'],['sales','Sales / Invoices'],['salereturn','Sale Return'],['customers','Customers'],['purchases','Purchases'],['purchasereturn','Purchase Return'],['suppliers','Suppliers'],['products','Products'],['stock','Stock Control'],['payments','Payments'],['expenses','Expenses'],['cashbook','Cash Book'],['reports','Reports'],['activity','Staff Activity'],['users','Users'],['backup','Backup'],['settings','Settings']];
const CASHIER_PERMS=['pos','sales','salereturn','customers','purchases','purchasereturn','suppliers','products','stock','payments','expenses'];
function hash(s){s='hz|'+s;let h1=0xdeadbeef,h2=0x41c6ce57;for(let i=0;i<s.length;i++){const c=s.charCodeAt(i);h1=Math.imul(h1^c,2654435761);h2=Math.imul(h2^c,1597334677);}h1=Math.imul(h1^(h1>>>16),2246822507)^Math.imul(h2^(h2>>>13),3266489909);h2=Math.imul(h2^(h2>>>16),2246822507)^Math.imul(h1^(h1>>>13),3266489909);return(4294967296*(2097151&h2)+(h1>>>0)).toString(36);}

/* ================= storage ================= */
let db=null, cur=null, cache={};
const DBN='humza_pos_v1', STORE='kv';
function idb(){return new Promise((res,rej)=>{const r=indexedDB.open(DBN,1);r.onupgradeneeded=()=>r.result.createObjectStore(STORE);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});}
async function kvGet(k){try{const d=await idb();return await new Promise((res,rej)=>{const q=d.transaction(STORE).objectStore(STORE).get(k);q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error);});}catch(e){try{const v=localStorage.getItem('hz_'+k);return v?JSON.parse(v):undefined;}catch(_){return undefined;}}}
async function kvSet(k,v){try{const d=await idb();await new Promise((res,rej)=>{const t=d.transaction(STORE,'readwrite');t.objectStore(STORE).put(v,k);t.oncomplete=res;t.onerror=()=>rej(t.error);});}catch(e){try{localStorage.setItem('hz_'+k,JSON.stringify(v));}catch(_){}}}
async function kvDel(k){try{const d=await idb();await new Promise((res)=>{const t=d.transaction(STORE,'readwrite');t.objectStore(STORE).delete(k);t.oncomplete=res;t.onerror=res;});}catch(e){}}
let saveT=null;
function save(){cache={};clearTimeout(saveT);saveT=setTimeout(flush,400);}
function flush(){clearTimeout(saveT);if(db){if(window.mirrorSoon)mirrorSoon();return kvSet('db',db);}}
window.addEventListener('pagehide',flush);document.addEventListener('visibilitychange',()=>{if(document.hidden)flush();});

const APP_VERSION='1.3.1';
const UPDATE_REPO_DEFAULT='';
function newDB(){return{v:1,settings:{shop:'Humza Plastic Store',shopUr:'ہمزہ پلاسٹک اسٹور',updateRepo:'',lastUpdateCheck:'',skipVersion:'',addrUr:'ملتان',footerUr:'شکریہ! خریدا ہوا مال بل کے بغیر واپس نہیں ہوگا۔',logo:'',invoiceLang:'ur',urduFont:'auto',urduSize:100,urduBold:false,driveDir:'',tag:'Plastic Items - Wholesale & Retail',addr:'',phone:'',whatsapp:'',footer:'Thank you for your business! Goods once sold will not be returned without bill.',openingCash:0,deadDays:60,overdueDays:30,showCost:true,lastBackup:'',defaultPw:true,requireLogin:false,printAfterSave:true},
 users:[{id:'u1',name:'Owner',username:'admin',pw:hash('admin123'),role:'owner',active:true,perms:[]},{id:'u2',name:'Cashier',username:'cashier',pw:hash('1234'),role:'cashier',active:true,perms:CASHIER_PERMS.slice()}],
 products:[],customers:[],suppliers:[],sales:[],purchases:[],salesReturns:[],purchaseReturns:[],payments:[],expenses:[],stockMoves:[],activity:[],
 counters:{sale:0,purchase:0,sret:0,pret:0,rcv:0,pay:0,exp:0,code:1000}};}
function nextNo(prefix,key){db.counters[key]=(db.counters[key]||0)+1;return prefix+String(db.counters[key]).padStart(6,'0');}
function log(action){if(!db)return;db.activity.push({id:uid(),ts:Date.now(),date:today(),user:cur?cur.name:'System',action});if(db.activity.length>4000)db.activity.splice(0,500);}
const can=m=>cur&&(cur.role==='owner'||(cur.perms||[]).includes(m));

/* ================= lookups ================= */
const P=id=>db.products.find(x=>x.id===id), C=id=>db.customers.find(x=>x.id===id), S=id=>db.suppliers.find(x=>x.id===id);
const custName=id=>id?(C(id)?C(id).name:'(deleted)'):'Walk-in Customer';
const suppName=id=>S(id)?S(id).name:'(deleted)';
const memo=(k,f)=>k in cache?cache[k]:(cache[k]=f());

/* ================= stock ================= */
function moveStock(pid,qty,type,ref,note,date){const p=P(pid);if(!p)return;p.stock=r3((+p.stock||0)+qty);db.stockMoves.push({id:uid(),ts:Date.now(),date:date||today(),pid,qty:r3(qty),type,ref:ref||'',note:note||'',user:cur?cur.name:'',bal:p.stock});}
const lowItems=()=>db.products.filter(p=>p.active!==false&&p.min>0&&p.stock<=p.min);
function lastSaleMap(){return memo('lsm',()=>{const m={};db.sales.forEach(s=>s.items.forEach(i=>{if(!m[i.pid]||m[i.pid]<s.date)m[i.pid]=s.date;}));return m;});}

/* ================= transactions ================= */
function createSale(d){
 const items=d.items.map(i=>({pid:i.pid,name:i.name,nameUr:(P(i.pid)&&P(i.pid).nameUr)||'',unit:i.unit||'',qty:+i.qty,rate:+i.rate,cost:+(P(i.pid)?P(i.pid).cost:0)||0,disc:+i.disc||0,amount:r2(i.qty*i.rate-(+i.disc||0))}));
 const subtotal=r2(sum(items,'amount')),discount=r2(Math.min(Math.max(+d.discount||0,0),subtotal)),total=r2(subtotal-discount);
 const paid=r2(Math.min(Math.max(+d.paid||0,0),total));
 const s={id:uid(),no:nextNo('INV-','sale'),date:d.date||today(),ts:Date.now(),customerId:d.customerId||'',items,subtotal,discount,total,paid,due:r2(total-paid),method:d.method||'Cash',user:cur.name,note:d.note||''};
 db.sales.push(s);items.forEach(i=>moveStock(i.pid,-i.qty,'Sale',s.no,custName(s.customerId),s.date));
 log(`Sale ${s.no} ${money(total)} (${custName(s.customerId)})`);save();return s;}
function createPurchase(d){
 const items=d.items.map(i=>({pid:i.pid,name:i.name,unit:i.unit||'',qty:+i.qty,rate:+i.rate,disc:+i.disc||0,amount:r2(i.qty*i.rate-(+i.disc||0))}));
 const subtotal=r2(sum(items,'amount')),discount=r2(Math.min(Math.max(+d.discount||0,0),subtotal)),total=r2(subtotal-discount);
 const paid=r2(Math.min(Math.max(+d.paid||0,0),total));
 const p={id:uid(),no:nextNo('PUR-','purchase'),billNo:d.billNo||'',date:d.date||today(),ts:Date.now(),supplierId:d.supplierId,items,subtotal,discount,total,paid,due:r2(total-paid),method:d.method||'Cash',user:cur.name,note:d.note||''};
 db.purchases.push(p);
 const ratio=subtotal?total/subtotal:1;
 items.forEach(i=>{moveStock(i.pid,i.qty,'Purchase',p.no,suppName(p.supplierId),p.date);const pr=P(i.pid);if(pr&&i.qty>0){pr.cost=r2(i.amount*ratio/i.qty);if(!pr.supplierId)pr.supplierId=p.supplierId;}});
 log(`Purchase ${p.no} ${money(total)} (${suppName(p.supplierId)})`);save();return p;}
function returnedQty(saleId,pid){return sum(db.salesReturns.filter(r=>r.saleId===saleId),r=>sum(r.items.filter(i=>i.pid===pid),'qty'));}
function preturnedQty(purId,pid){return sum(db.purchaseReturns.filter(r=>r.purchaseId===purId),r=>sum(r.items.filter(i=>i.pid===pid),'qty'));}
function createSaleReturn(d){
 const sale=db.sales.find(s=>s.id===d.saleId);
 const items=d.items.filter(i=>i.qty>0).map(i=>{const l=sale.items.find(x=>x.pid===i.pid);return{pid:i.pid,name:l.name,qty:+i.qty,rate:+i.rate,cost:l.cost,amount:r2(i.qty*i.rate)};});
 const total=r2(sum(items,'amount'));
 const mode=sale.customerId?d.mode:'cash';
 const r={id:uid(),no:nextNo('SR-','sret'),date:d.date||today(),ts:Date.now(),saleId:sale.id,saleNo:sale.no,customerId:sale.customerId,items,total,mode,method:d.method||'Cash',reason:d.reason||'',user:cur.name};
 db.salesReturns.push(r);items.forEach(i=>moveStock(i.pid,i.qty,'Sale Return',r.no,sale.no,r.date));
 log(`Sale return ${r.no} on ${sale.no} ${money(total)} (${mode==='cash'?'cash refund':'customer credit'})`);save();return r;}
function createPurchaseReturn(d){
 const pu=db.purchases.find(s=>s.id===d.purchaseId);
 const items=d.items.filter(i=>i.qty>0).map(i=>{const l=pu.items.find(x=>x.pid===i.pid);return{pid:i.pid,name:l.name,qty:+i.qty,rate:+i.rate,amount:r2(i.qty*i.rate)};});
 const total=r2(sum(items,'amount'));
 const r={id:uid(),no:nextNo('PR-','pret'),date:d.date||today(),ts:Date.now(),purchaseId:pu.id,purchaseNo:pu.no,supplierId:pu.supplierId,items,total,mode:d.mode||'adjust',method:d.method||'Cash',reason:d.reason||'',user:cur.name};
 db.purchaseReturns.push(r);items.forEach(i=>moveStock(i.pid,-i.qty,'Purchase Return',r.no,pu.no,r.date));
 log(`Purchase return ${r.no} on ${pu.no} ${money(total)}`);save();return r;}
function addPayment(d){
 const p={id:uid(),no:nextNo(d.type==='cust'?'RCV-':'PAY-',d.type==='cust'?'rcv':'pay'),date:d.date||today(),ts:Date.now(),type:d.type,partyId:d.partyId,amount:r2(d.amount),method:d.method||'Cash',note:d.note||'',user:cur.name};
 db.payments.push(p);log(`${d.type==='cust'?'Received':'Paid'} ${money(p.amount)} ${d.type==='cust'?'from '+custName(p.partyId):'to '+suppName(p.partyId)} (${p.no})`);save();return p;}
function addExpense(d){
 const e={id:uid(),no:nextNo('EXP-','exp'),date:d.date||today(),ts:Date.now(),category:d.category,desc:d.desc||'',amount:r2(d.amount),method:d.method||'Cash',user:cur.name};
 db.expenses.push(e);log(`Expense ${e.no} ${e.category} ${money(e.amount)}`);save();return e;}
function voidSale(id){const s=db.sales.find(x=>x.id===id);if(!s)return'Not found';if(db.salesReturns.some(r=>r.saleId===id))return'This invoice has returns. Cannot cancel.';
 s.items.forEach(i=>moveStock(i.pid,i.qty,'Cancelled Sale',s.no,'Invoice cancelled',today()));db.sales=db.sales.filter(x=>x.id!==id);log(`CANCELLED invoice ${s.no} ${money(s.total)}`);save();return null;}
function voidPurchase(id){const s=db.purchases.find(x=>x.id===id);if(!s)return'Not found';if(db.purchaseReturns.some(r=>r.purchaseId===id))return'This purchase has returns. Cannot cancel.';
 s.items.forEach(i=>moveStock(i.pid,-i.qty,'Cancelled Purchase',s.no,'Purchase cancelled',today()));db.purchases=db.purchases.filter(x=>x.id!==id);log(`CANCELLED purchase ${s.no} ${money(s.total)}`);save();return null;}

/* ================= ledgers ================= */
const cmp=(a,b)=>a.date<b.date?-1:a.date>b.date?1:a.ts-b.ts;
function custEntries(id){const c=C(id);const e=[];if(!c)return e;
 if(c.opening)e.push({date:'0000-00-00',ts:0,ref:'',desc:'Opening Balance',dr:c.opening>0?c.opening:0,cr:c.opening<0?-c.opening:0,kind:'open'});
 db.sales.filter(s=>s.customerId===id).forEach(s=>e.push({date:s.date,ts:s.ts,ref:s.no,desc:`Sale Invoice (${s.items.length} items)`+(s.paid>0?` - paid ${money(s.paid)}`:''),dr:s.total,cr:s.paid,kind:'sale',id:s.id}));
 db.payments.filter(p=>p.type==='cust'&&p.partyId===id).forEach(p=>e.push({date:p.date,ts:p.ts,ref:p.no,desc:'Payment received ('+p.method+')'+(p.note?' - '+p.note:''),dr:0,cr:p.amount,kind:'pay',id:p.id}));
 db.salesReturns.filter(r=>r.customerId===id&&r.mode==='credit').forEach(r=>e.push({date:r.date,ts:r.ts,ref:r.no,desc:'Sale return (credit) of '+r.saleNo,dr:0,cr:r.total,kind:'ret',id:r.id}));
 e.sort(cmp);let b=0;e.forEach(x=>{b=r2(b+x.dr-x.cr);x.bal=b;});return e;}
function suppEntries(id){const s0=S(id);const e=[];if(!s0)return e;
 if(s0.opening)e.push({date:'0000-00-00',ts:0,ref:'',desc:'Opening Balance',dr:s0.opening<0?-s0.opening:0,cr:s0.opening>0?s0.opening:0,kind:'open'});
 db.purchases.filter(p=>p.supplierId===id).forEach(p=>e.push({date:p.date,ts:p.ts,ref:p.no,desc:`Purchase bill ${p.billNo||''}`+(p.paid>0?` - paid ${money(p.paid)}`:''),dr:p.paid,cr:p.total,kind:'pur',id:p.id}));
 db.payments.filter(p=>p.type==='supp'&&p.partyId===id).forEach(p=>e.push({date:p.date,ts:p.ts,ref:p.no,desc:'Payment made ('+p.method+')'+(p.note?' - '+p.note:''),dr:p.amount,cr:0,kind:'pay',id:p.id}));
 db.purchaseReturns.filter(r=>r.supplierId===id&&r.mode==='adjust').forEach(r=>e.push({date:r.date,ts:r.ts,ref:r.no,desc:'Purchase return adjusted of '+r.purchaseNo,dr:r.total,cr:0,kind:'ret',id:r.id}));
 e.sort(cmp);let b=0;e.forEach(x=>{b=r2(b+x.cr-x.dr);x.bal=b;});return e;}
function custBals(){return memo('cb',()=>{const m={};db.customers.forEach(c=>m[c.id]=+c.opening||0);db.sales.forEach(s=>{if(s.customerId&&s.customerId in m)m[s.customerId]+=s.due;});db.payments.forEach(p=>{if(p.type==='cust'&&p.partyId in m)m[p.partyId]-=p.amount;});db.salesReturns.forEach(r=>{if(r.mode==='credit'&&r.customerId in m)m[r.customerId]-=r.total;});for(const k in m)m[k]=r2(m[k]);return m;});}
function suppBals(){return memo('sb',()=>{const m={};db.suppliers.forEach(c=>m[c.id]=+c.opening||0);db.purchases.forEach(s=>{if(s.supplierId in m)m[s.supplierId]+=s.due;});db.payments.forEach(p=>{if(p.type==='supp'&&p.partyId in m)m[p.partyId]-=p.amount;});db.purchaseReturns.forEach(r=>{if(r.mode==='adjust'&&r.supplierId in m)m[r.supplierId]-=r.total;});for(const k in m)m[k]=r2(m[k]);return m;});}
const custBal=id=>id?(custBals()[id]||0):0, suppBal=id=>suppBals()[id]||0;
function custInfo(id){const sales=db.sales.filter(s=>s.customerId===id);const pays=db.payments.filter(p=>p.type==='cust'&&p.partyId===id);
 const ls=sales.reduce((a,s)=>a>s.date?a:s.date,''),lp=pays.reduce((a,s)=>a>s.date?a:s.date,'');
 /* FIFO aging: oldest unpaid charge date */
 const bal=custBal(id);let oldest='';
 if(bal>0){const c=C(id);const ch=[];if(c.opening>0)ch.push({date:c.created||'0000-00-00',amt:c.opening});sales.filter(s=>s.due>0).sort(cmp).forEach(s=>ch.push({date:s.date,amt:s.due}));
  let credit=r2(sum(ch,'amt')-bal);for(const x of ch){if(credit>=x.amt){credit-=x.amt;continue;}oldest=x.date;break;}}
 return{lastSale:ls,lastPay:lp,oldest,age:oldest?Math.max(0,daysBetween(oldest.startsWith('0000')?today():oldest,today())):0,bal};}
function cashEntries(){const e=[];
 db.sales.forEach(s=>s.paid>0&&e.push({date:s.date,ts:s.ts,ref:s.no,desc:'Sale - '+custName(s.customerId),in:s.paid,out:0,method:s.method,kind:'Sale'}));
 db.payments.forEach(p=>e.push({date:p.date,ts:p.ts,ref:p.no,desc:p.type==='cust'?'Received from '+custName(p.partyId):'Paid to '+suppName(p.partyId),in:p.type==='cust'?p.amount:0,out:p.type==='supp'?p.amount:0,method:p.method,kind:p.type==='cust'?'Customer Payment':'Supplier Payment'}));
 db.purchases.forEach(p=>p.paid>0&&e.push({date:p.date,ts:p.ts,ref:p.no,desc:'Purchase - '+suppName(p.supplierId),in:0,out:p.paid,method:p.method,kind:'Purchase'}));
 db.expenses.forEach(x=>e.push({date:x.date,ts:x.ts,ref:x.no,desc:'Expense - '+x.category+(x.desc?' ('+x.desc+')':''),in:0,out:x.amount,method:x.method,kind:'Expense'}));
 db.salesReturns.forEach(r=>r.mode==='cash'&&e.push({date:r.date,ts:r.ts,ref:r.no,desc:'Sale return refund - '+custName(r.customerId),in:0,out:r.total,method:r.method,kind:'Sale Return'}));
 db.purchaseReturns.forEach(r=>r.mode==='cash'&&e.push({date:r.date,ts:r.ts,ref:r.no,desc:'Purchase return refund - '+suppName(r.supplierId),in:r.total,out:0,method:r.method,kind:'Purchase Return'}));
 return e.sort(cmp);}
const cashOnHand=()=>memo('coh',()=>r2((+db.settings.openingCash||0)+sum(cashEntries().filter(e=>e.method==='Cash'),e=>e.in-e.out)));

/* ================= profit ================= */
function saleProfit(s){const ratio=s.subtotal?s.total/s.subtotal:1;return r2(sum(s.items,i=>i.amount*ratio-i.cost*i.qty));}
const retProfit=r=>r2(sum(r.items,i=>i.amount-i.cost*i.qty));
function periodStats(f,t){
 const S_=db.sales.filter(s=>s.date>=f&&s.date<=t),R_=db.salesReturns.filter(s=>s.date>=f&&s.date<=t),PU=db.purchases.filter(s=>s.date>=f&&s.date<=t),PY=db.payments.filter(s=>s.date>=f&&s.date<=t),EX=db.expenses.filter(s=>s.date>=f&&s.date<=t);
 const gross=r2(sum(S_,saleProfit)-sum(R_,retProfit));const exp=sum(EX,'amount');
 return{sales:sum(S_,'total'),count:S_.length,received:sum(S_,'paid')+sum(PY.filter(p=>p.type==='cust'),'amount'),recovered:sum(PY.filter(p=>p.type==='cust'),'amount'),udhaar:sum(S_,'due'),purchase:sum(PU,'total'),supplierPaid:sum(PY.filter(p=>p.type==='supp'),'amount')+sum(PU,'paid'),supplierPaidOnly:sum(PY.filter(p=>p.type==='supp'),'amount'),returns:sum(R_,'total'),gross,expenses:exp,profit:r2(gross-exp),discount:sum(S_,s=>s.discount+sum(s.items,'disc'))};}
const stockValue=()=>memo('sv',()=>r2(sum(db.products.filter(p=>p.stock>0),p=>p.stock*p.cost)));
function topItems(f,t,n=10){const m={};db.sales.filter(s=>s.date>=f&&s.date<=t).forEach(s=>{const ratio=s.subtotal?s.total/s.subtotal:1;s.items.forEach(i=>{const x=m[i.pid]||(m[i.pid]={pid:i.pid,name:i.name,qty:0,amount:0,profit:0});x.qty+=i.qty;x.amount+=i.amount*ratio;x.profit+=i.amount*ratio-i.cost*i.qty;});});return Object.values(m).sort((a,b)=>b.amount-a.amount).slice(0,n);}
function topCustomers(f,t,n=10){const m={};db.sales.filter(s=>s.date>=f&&s.date<=t&&s.customerId).forEach(s=>{const x=m[s.customerId]||(m[s.customerId]={id:s.customerId,name:custName(s.customerId),count:0,amount:0});x.count++;x.amount+=s.total;});return Object.values(m).sort((a,b)=>b.amount-a.amount).slice(0,n);}

/* ================= whatsapp / phone ================= */
function waNum(p){let d=String(p||'').replace(/\D/g,'');if(!d)return'';if(d.startsWith('00'))d=d.slice(2);else if(d.startsWith('0'))d='92'+d.slice(1);return d;}
function openWA(phone,text){const n=waNum(phone);window.open('https://wa.me/'+n+'?text='+encodeURIComponent(text),'_blank');}

/* ===== auto-fit: scale whole UI to the PC's screen (designed for 1280x720) ===== */
function fitScreen(){const w=innerWidth,h=innerHeight;let z=Math.min(w/1280,h/720);z=Math.max(.6,Math.min(1.6,z));z=Math.round(z*100)/100;
 const H=document.documentElement;H.style.zoom=z;H.classList.toggle('hs',h/z<=800);H.classList.toggle('hm',h/z<=900);H.classList.toggle('ws',w/z<=1380);document.documentElement.style.setProperty('--vh',(h/z)+'px');}
fitScreen();addEventListener('resize',fitScreen);
