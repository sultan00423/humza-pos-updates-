package main

import (
	"encoding/json"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"sync/atomic"
	"syscall"
	"time"
)

const addr = "127.0.0.1:48731"

type Config struct {
	DriveDir string `json:"driveDir"`
}

var (
	exeDir   string
	appData  string // %LOCALAPPDATA%\HumzaPlasticStore
	dataRoot string // Documents\HumzaPlasticStore
	lastPing int64
	started  int64
)

func hide(c *exec.Cmd) *exec.Cmd {
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	return c
}

func cfgPath() string { return filepath.Join(appData, "config.json") }
func loadCfg() Config {
	var c Config
	if b, err := os.ReadFile(cfgPath()); err == nil {
		json.Unmarshal(b, &c)
	}
	return c
}
func saveCfg(c Config) {
	b, _ := json.Marshal(c)
	os.WriteFile(cfgPath(), b, 0644)
}

func writeAtomic(path string, data []byte) error {
	os.MkdirAll(filepath.Dir(path), 0755)
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, data, 0644); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

func prune(dir string, keep int) {
	ents, _ := os.ReadDir(dir)
	var names []string
	for _, e := range ents {
		if !e.IsDir() && strings.HasPrefix(e.Name(), "HumzaBackup_") {
			names = append(names, e.Name())
		}
	}
	sort.Strings(names)
	for len(names) > keep {
		os.Remove(filepath.Join(dir, names[0]))
		names = names[1:]
	}
}

func driveCandidates() []string {
	home, _ := os.UserHomeDir()
	c := []string{filepath.Join(home, "Google Drive"), filepath.Join(home, "My Drive"), filepath.Join(home, "Google Drive", "My Drive")}
	for _, l := range "DEFGHIJKLMNOPQRSTUVWXYZ" {
		c = append(c, string(l)+`:\My Drive`, string(l)+`:\Google Drive`)
	}
	var out []string
	for _, p := range c {
		if st, err := os.Stat(p); err == nil && st.IsDir() {
			out = append(out, p)
		}
	}
	return out
}

func js(w http.ResponseWriter, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(v)
}

func guard(h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("X-HP") != "1" {
			http.Error(w, "forbidden", 403)
			return
		}
		atomic.StoreInt64(&lastPing, time.Now().Unix())
		h(w, r)
	}
}

func serve() {
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" && r.URL.Path != "/index.html" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Cache-Control", "no-store")
		http.ServeFile(w, r, filepath.Join(exeDir, "index.html"))
	})
	mux.HandleFunc("/api/ping", guard(func(w http.ResponseWriter, r *http.Request) { js(w, map[string]bool{"ok": true}) }))
	mux.HandleFunc("/api/config", guard(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" {
			var c Config
			json.NewDecoder(r.Body).Decode(&c)
			saveCfg(c)
		}
		c := loadCfg()
		js(w, map[string]interface{}{"dataDir": filepath.Join(dataRoot, "Data"), "backupDir": filepath.Join(dataRoot, "Backups"), "driveDir": c.DriveDir, "found": driveCandidates()})
	}))
	mux.HandleFunc("/api/pick", guard(func(w http.ResponseWriter, r *http.Request) {
		ps := `Add-Type -AssemblyName System.Windows.Forms;$f=New-Object System.Windows.Forms.FolderBrowserDialog;$f.Description='Google Drive folder chunen';$f.ShowNewFolderButton=$true;$t=New-Object System.Windows.Forms.Form;$t.TopMost=$true;if($f.ShowDialog($t) -eq 'OK'){[Console]::Out.Write($f.SelectedPath)}`
		out, _ := hide(exec.Command("powershell", "-NoProfile", "-STA", "-Command", ps)).Output()
		js(w, map[string]string{"path": strings.TrimSpace(string(out))})
	}))
	mux.HandleFunc("/api/mirror", guard(func(w http.ResponseWriter, r *http.Request) {
		b, _ := io.ReadAll(r.Body)
		p := filepath.Join(dataRoot, "Data", "current.json")
		if old, err := os.ReadFile(p); err == nil && len(old) > 0 {
			writeAtomic(filepath.Join(dataRoot, "Data", "previous.json"), old)
		}
		err := writeAtomic(p, b)
		js(w, map[string]interface{}{"ok": err == nil})
	}))
	mux.HandleFunc("/api/backup", guard(func(w http.ResponseWriter, r *http.Request) {
		b, _ := io.ReadAll(r.Body)
		now := time.Now()
		name := "HumzaBackup_" + now.Format("2006-01-02") + ".json"
		if r.URL.Query().Get("kind") == "manual" {
			name = "HumzaBackup_" + now.Format("2006-01-02_1504") + ".json"
		}
		res := map[string]interface{}{"ok": true}
		bd := filepath.Join(dataRoot, "Backups")
		if err := writeAtomic(filepath.Join(bd, name), b); err != nil {
			res["ok"] = false
			res["error"] = err.Error()
		}
		prune(bd, 90)
		c := loadCfg()
		if c.DriveDir != "" {
			dd := filepath.Join(c.DriveDir, "HumzaPlasticStoreBackup")
			if err := writeAtomic(filepath.Join(dd, name), b); err != nil {
				res["driveError"] = err.Error()
			} else {
				res["drive"] = dd
				prune(dd, 90)
			}
		}
		res["file"] = filepath.Join(bd, name)
		js(w, res)
	}))
	mux.HandleFunc("/api/latest", guard(func(w http.ResponseWriter, r *http.Request) {
		if b, err := os.ReadFile(filepath.Join(dataRoot, "Data", "current.json")); err == nil && len(b) > 10 {
			w.Header().Set("Content-Type", "application/json")
			w.Write(b)
			return
		}
		bd := filepath.Join(dataRoot, "Backups")
		ents, _ := os.ReadDir(bd)
		var names []string
		for _, e := range ents {
			if strings.HasPrefix(e.Name(), "HumzaBackup_") {
				names = append(names, e.Name())
			}
		}
		sort.Strings(names)
		if len(names) > 0 {
			if b, err := os.ReadFile(filepath.Join(bd, names[len(names)-1])); err == nil {
				w.Header().Set("Content-Type", "application/json")
				w.Write(b)
				return
			}
		}
		http.NotFound(w, r)
	}))
	srv := &http.Server{Handler: mux}
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return
	}
	go srv.Serve(ln)
	// exit when the app window is closed (no heartbeat)
	go func() {
		for {
			time.Sleep(10 * time.Second)
			lp := atomic.LoadInt64(&lastPing)
			now := time.Now().Unix()
			if (lp == 0 && now-started > 180) || (lp != 0 && now-lp > 75) {
				os.Exit(0)
			}
		}
	}()
}

func browser() string {
	local := os.Getenv("LOCALAPPDATA")
	pf, pf86 := os.Getenv("ProgramFiles"), os.Getenv("ProgramFiles(x86)")
	for _, b := range []string{
		filepath.Join(pf86, `Microsoft\Edge\Application\msedge.exe`),
		filepath.Join(pf, `Microsoft\Edge\Application\msedge.exe`),
		filepath.Join(pf, `Google\Chrome\Application\chrome.exe`),
		filepath.Join(pf86, `Google\Chrome\Application\chrome.exe`),
		filepath.Join(local, `Google\Chrome\Application\chrome.exe`),
	} {
		if _, err := os.Stat(b); err == nil {
			return b
		}
	}
	return ""
}

func main() {
	exe, _ := os.Executable()
	exeDir = filepath.Dir(exe)
	local := os.Getenv("LOCALAPPDATA")
	appData = filepath.Join(local, "HumzaPlasticStore")
	home, _ := os.UserHomeDir()
	dataRoot = filepath.Join(home, "Documents", "HumzaPlasticStore")
	os.MkdirAll(appData, 0755)
	os.MkdirAll(filepath.Join(dataRoot, "Data"), 0755)
	os.MkdirAll(filepath.Join(dataRoot, "Backups"), 0755)
	prof := filepath.Join(local, "HumzaPlasticShop", "profile")
	os.MkdirAll(prof, 0755)
	started = time.Now().Unix()

	running := false
	if c, err := net.DialTimeout("tcp", addr, 500*time.Millisecond); err == nil {
		c.Close()
		running = true
	}
	if !running {
		serve()
		time.Sleep(300 * time.Millisecond)
	}
	url := "http://" + addr + "/"
	if b := browser(); b != "" {
		exec.Command(b, "--app="+url, "--user-data-dir="+prof, "--start-maximized", "--kiosk-printing", "--no-first-run", "--no-default-browser-check", "--disable-features=Translate").Start()
	} else {
		exec.Command("cmd", "/c", "start", "", url).Start()
	}
	if running {
		return
	}
	select {} // keep serving until heartbeat stops
}
