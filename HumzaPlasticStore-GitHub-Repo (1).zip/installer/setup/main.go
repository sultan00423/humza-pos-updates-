package main

import (
	_ "embed"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
)

//go:embed index.html
var indexHTML []byte

//go:embed launcher.exe
var launcher []byte

//go:embed HumzaPOS.ico
var icon []byte

const app = "Humza Plastic Store POS"
const regKey = `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\HumzaPlasticShopPOS`

func ps(script string) error {
	c := exec.Command("powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	return c.Run()
}
func msg(text string) {
	ps(fmt.Sprintf(`Add-Type -AssemblyName PresentationFramework;[void][System.Windows.MessageBox]::Show('%s','%s')`, text, app))
}
func installDir() string { return filepath.Join(os.Getenv("LOCALAPPDATA"), "HumzaPlasticShop", "App") }

func install() {
	d := installDir()
	if err := os.MkdirAll(d, 0755); err != nil {
		msg("Install failed: " + err.Error())
		os.Exit(1)
	}
	ps(`Get-Process msedge,chrome -ErrorAction SilentlyContinue | Where-Object {$_.CommandLine -like '*HumzaPlasticShop*'} | Stop-Process -Force`)
	for n, b := range map[string][]byte{"index.html": indexHTML, "HumzaPOS.exe": launcher, "HumzaPOS.ico": icon} {
		if err := os.WriteFile(filepath.Join(d, n), b, 0755); err != nil {
			msg("Install failed: " + err.Error())
			os.Exit(1)
		}
	}
	self, _ := os.Executable()
	data, _ := os.ReadFile(self)
	os.WriteFile(filepath.Join(d, "Uninstall.exe"), data, 0755)
	exe, ico := filepath.Join(d, "HumzaPOS.exe"), filepath.Join(d, "HumzaPOS.ico")
	mk := func(path string) string {
		return fmt.Sprintf(`$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%s');$s.TargetPath='%s';$s.WorkingDirectory='%s';$s.IconLocation='%s';$s.Description='%s';$s.Save();`, path, exe, d, ico, app)
	}
	script := `$desk=[Environment]::GetFolderPath('Desktop');$sm=Join-Path ([Environment]::GetFolderPath('Programs')) 'Humza Plastic Store';New-Item -ItemType Directory -Force $sm|Out-Null;` +
		mk(`$desk\Humza POS.lnk`) + mk(`$sm\Humza POS.lnk`) +
		fmt.Sprintf(`$u=(New-Object -ComObject WScript.Shell).CreateShortcut("$sm\Uninstall.lnk");$u.TargetPath='%s';$u.Arguments='/uninstall';$u.Save();`, filepath.Join(d, "Uninstall.exe"))
	ps(script)
	reg := func(k, t, v string) {
		exec.Command("reg", "add", regKey, "/v", k, "/t", t, "/d", v, "/f").Run()
	}
	reg("DisplayName", "REG_SZ", app)
	reg("DisplayIcon", "REG_SZ", ico)
	reg("Publisher", "REG_SZ", "Humza Plastic Store")
	reg("InstallLocation", "REG_SZ", d)
	reg("UninstallString", "REG_SZ", `"`+filepath.Join(d, "Uninstall.exe")+`" /uninstall`)
	exec.Command(exe).Start()
	msg("Installation complete! Desktop par 'Humza POS' icon ban gaya hai.")
}

func uninstall() {
	ps(`Add-Type -AssemblyName PresentationFramework;if([System.Windows.MessageBox]::Show('Software uninstall karna hai? (Aap ka data delete nahi hoga)','Uninstall','YesNo') -ne 'Yes'){exit 1}`)
	d := installDir()
	// run cleanup after this process exits
	script := fmt.Sprintf(`Start-Sleep 2;Remove-Item -Recurse -Force '%s';$desk=[Environment]::GetFolderPath('Desktop');Remove-Item -Force "$desk\Humza POS.lnk" -ErrorAction SilentlyContinue;Remove-Item -Recurse -Force (Join-Path ([Environment]::GetFolderPath('Programs')) 'Humza Plastic Store') -ErrorAction SilentlyContinue;reg delete '%s' /f`, d, regKey)
	c := exec.Command("powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", script)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	c.Start()
}

func main() {
	if len(os.Args) > 1 && os.Args[1] == "/uninstall" {
		uninstall()
		return
	}
	install()
}
