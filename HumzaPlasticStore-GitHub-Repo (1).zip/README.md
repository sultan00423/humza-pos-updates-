# Humza Plastic Store - POS

Offline POS / accounts software (single HTML app + Windows installer).

## Build
`bash build.sh` -> `dist/HumzaPlasticShop-POS.html`. Windows installer: see `.github/workflows/release.yml` (Go cross-compile).

## Release / update (no server needed)
1. Change `APP_VERSION` in `src/base.js` (e.g. `1.3.0`) and commit.
2. `git tag v1.3.0 && git push origin v1.3.0`
3. GitHub Actions builds `HumzaPlasticStore-Setup.exe` and publishes it as a Release.
4. Every client's software checks `https://api.github.com/repos/<owner>/<repo>/releases/latest` once a day (and from Settings > Check for Updates) and offers the download. Client data stays safe.

Update repo name: humza-pos-updates (public). See HOW_TO_RELEASE.txt.

## Data safety (Windows installed version)
The launcher runs a tiny local service (127.0.0.1:48731). It mirrors all data to `Documents\HumzaPlasticStore\Data`, writes daily backups to `Documents\HumzaPlasticStore\Backups` and, if a Google Drive folder is chosen in Settings > Backup & Data, copies each backup there (Google Drive for desktop uploads it with the client's Google ID). If browser data is ever lost the software restores itself from the PC copy.
